export function subtract(firstnumber: number, secondnumber: number): number {
    return firstnumber - secondnumber;
}
