# Project Architecture

This project has the following architecture:

![Architecture Diagram](./architecture_diagram.png)
