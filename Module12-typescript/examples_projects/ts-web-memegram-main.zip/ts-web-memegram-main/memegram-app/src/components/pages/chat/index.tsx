import ChatsDashboard from '../../Thatpix-Chat/ChatIntefaceAndDashboard/ChatsDashboard';

export default function ChatPage(): JSX.Element {
    
    return (
        <>       
            <ChatsDashboard />
        </>
       
    )
}
