export enum NavItemEnum {
  newPost = 'New Post',
  chats = 'Chats',
  logout = 'Logout',
  home = 'Home / Feed'
}
