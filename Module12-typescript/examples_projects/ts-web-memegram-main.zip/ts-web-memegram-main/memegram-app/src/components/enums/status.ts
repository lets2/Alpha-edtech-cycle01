export enum Status {
  default = 'default',
  error = 'error',
  success = 'success',
  focus = 'focus',
}
