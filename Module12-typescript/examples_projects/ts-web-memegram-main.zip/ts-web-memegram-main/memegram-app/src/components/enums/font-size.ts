export enum FontSize {
  extrasmall = 'fs-xsm',
  normal = 'fs-normal',
  large = 'fs-lg',
  largexl = 'fs-xl',
  large2xl = 'fs-2xl',
  large3xl = 'fs-3xl',
  large4xl = 'fs-4xl',
  large7xl = 'fs-7xl',
  large9xl = 'fs-9xl',
  large10xl = 'fs-10xl',
  large12xl = 'fs-12xl',
}
