export default interface iResp{
    data: any,
    error: String | null
}