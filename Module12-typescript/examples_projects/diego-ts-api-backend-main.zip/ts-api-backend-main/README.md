# ts-api-backend
Repositório com exemplo de aplicação back end em TypeScript para turma Hopper da Alpha.
