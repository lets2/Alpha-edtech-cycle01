export default interface IStorage {
    _id?: string;
    pathImage?: string;
}
