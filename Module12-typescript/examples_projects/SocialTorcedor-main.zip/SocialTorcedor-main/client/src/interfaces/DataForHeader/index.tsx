export interface dataForHeader {
    logo: String,
    alt: String,
    name: String,
    email: String
}
