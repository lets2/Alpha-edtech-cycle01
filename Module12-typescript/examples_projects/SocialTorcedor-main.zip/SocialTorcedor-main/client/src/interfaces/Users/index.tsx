export interface IUser {
    _id: string, // ID do usuário
    name: string, // Nome do usuário
    nickname: string, // Apelido do usuário
    team: string, // Time do usuário
    pathImage: string
}