import Routes from "./routes";
// import Home from "./pages/Home";
// import Login from "./pages/Login";
// import Register from "./pages/Register";
// import Update from "./pages/Update";

export default function App() {

    return <Routes />;
    //return <Home />
}
