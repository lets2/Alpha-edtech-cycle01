export const inputIsEmpty = (value: any): boolean => {
    return !value ? false : true;
};
