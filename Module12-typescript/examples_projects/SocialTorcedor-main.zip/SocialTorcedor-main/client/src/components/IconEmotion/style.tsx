import styled from "styled-components";

export const StyledEmotions = styled.img`
    width: 25px;
    height: 25px;
    cursor: pointer;
`;
