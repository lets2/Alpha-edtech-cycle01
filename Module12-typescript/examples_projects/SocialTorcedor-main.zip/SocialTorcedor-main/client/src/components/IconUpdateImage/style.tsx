import styled from "styled-components";

export const StyledUpdateImg = styled.img`
    height: 57px;
    width: 53px;
    margin-bottom: 5px;
    border-radius: 10px;
    `;
