import { createContext } from "react";

const Context = createContext(undefined as any);

export default Context;