export { reactToFeed } from './reactToFeed';
