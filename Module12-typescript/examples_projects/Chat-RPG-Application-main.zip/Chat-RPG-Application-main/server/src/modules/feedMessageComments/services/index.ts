export { create } from './createFeedComment';
export { deleteComment } from './deleteFeedComment';
