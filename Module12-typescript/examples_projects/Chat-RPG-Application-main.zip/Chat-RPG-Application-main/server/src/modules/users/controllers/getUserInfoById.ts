// import { Request, Response } from 'express';

// export async function getUserInfoById(req: Request, res: Response): Promise<void> {

// }
