import { TextField } from '@components/common';
import styled from 'styled-components';

export const ChatInput = styled(TextField)`
  width: 75%;
`;
