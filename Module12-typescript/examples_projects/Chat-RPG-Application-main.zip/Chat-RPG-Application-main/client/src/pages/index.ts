export * from 'pages/ChatRoom';
export * from 'pages/CreateGame';
export * from 'pages/Error404';
export * from 'pages/Feed';
export * from 'pages/Home';
export * from 'pages/MyGames';
export * from 'pages/Publication';
export * from 'pages/Register';
