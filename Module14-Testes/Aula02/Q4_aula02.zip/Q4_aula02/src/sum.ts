export function sum(firstNumber: number, secondNumber: number): number {
    return firstNumber + secondNumber;
}

export function sum3numbers(
    firstNumber: number,
    secondNumber: number,
    thirdNumber: number
): number {
    return firstNumber + secondNumber + thirdNumber;
}
