Veja o vídeo explicativo !

O arquivo .env já vem com credenciais de banco de dados,
mas você precisará trocar para as credenciais do seu banco !
Além disso, não recomendo usar o ElephantSQL porque ele é
lento, então esperar os testes rodarem pode ficar c-h-a-t-o
