module.exports = {
  ...require("./res-json-format"),
};
