// Added a bug intentionally in the function return
export function sum(firstNumber: number, secondNumber: number): number {
    return firstNumber * secondNumber;
}
