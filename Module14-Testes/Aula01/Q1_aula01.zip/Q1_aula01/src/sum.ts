export function sum(firstNumber: number, secondNumber: number): number {
    return firstNumber + secondNumber;
}
