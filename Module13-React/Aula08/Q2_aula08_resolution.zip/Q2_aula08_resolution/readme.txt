Para executar o backend:
Dentro do diretório BACKEND_TS use os comandos:
npx tsc
node dist/server.js
O backend está sendo servido na porta 80

Para executar o frontend
Dentro do diretório FRONTEND_react, use o comando:
npm run dev
O frontend/react está sendo servido na porta 5173.


UM exemplo de login valido é:
lets@gmail.com
123


