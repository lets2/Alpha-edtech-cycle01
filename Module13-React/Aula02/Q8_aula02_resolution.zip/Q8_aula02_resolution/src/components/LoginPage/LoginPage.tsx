import Form from "../Form/Form";
import "./LoginPage.css";

export default function LoginPage() {
    return (
        <div className="container-login">
            <h1>LOGIN</h1>
            <Form />
        </div>
    );
}
