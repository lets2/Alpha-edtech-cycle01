lembre-se do npm install, pois está sem os node_modules do backend e do first
Para executar o backend:
Dentro do diretório BACKEND_TS use os comandos:
npx tsc
node dist/server.js
O backend está sendo servido na porta 80

Para executar o frontend (/first)
Dentro do diretório first, use o comando:
npm start
O frontend/react está sendo servido na porta 3000.
