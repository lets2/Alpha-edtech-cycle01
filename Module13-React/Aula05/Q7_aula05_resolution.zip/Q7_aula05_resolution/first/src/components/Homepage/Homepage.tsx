import "./Homepage.css";

export default function Homepage() {
    return <h1>Home: sua página logada</h1>;
}
